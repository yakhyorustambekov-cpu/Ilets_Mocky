function updateCount(inputId, countId) {
  const el = document.getElementById(inputId);
  const countEl = document.getElementById(countId);
  el.addEventListener('input', function() {
    const text = el.value.trim();
    const words = text ? text.split(/\s+/).length : 0;
    countEl.textContent = words;
  });
}

updateCount('task1Text', 't1Count');
updateCount('task2Text', 't2Count');

document.getElementById('writingSubmitBtn').addEventListener('click', function() {
  const t1 = document.getElementById('task1Text').value;
  const t2 = document.getElementById('task2Text').value;
  const t1Words = t1.trim() ? t1.trim().split(/\s+/).length : 0;
  const t2Words = t2.trim() ? t2.trim().split(/\s+/).length : 0;

  if (window.parent) {
    window.parent.postMessage({
      type: 'IELTS_TEST_COMPLETE',
      section: 'WRITING',
      bandScore: 7.0,
      resultData: {
        task1Words: t1Words,
        task2Words: t2Words,
        submittedAt: new Date().toISOString()
      }
    }, '*');
  }

  alert('Writing Test 1 submitted successfully! Recorded Band 7.0 (Task 1: ' + t1Words + 'w, Task 2: ' + t2Words + 'w)');
});