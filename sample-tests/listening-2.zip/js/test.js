document.getElementById('submitBtn2').addEventListener('click', function() {
  const form = document.getElementById('listeningForm2');
  let filledCount = 0;
  const inputs = form.querySelectorAll('input');
  inputs.forEach(input => {
    if ((input.type === 'text' && input.value.trim()) || (input.type === 'radio' && input.checked)) {
      filledCount++;
    }
  });

  const score = Math.min(40, filledCount * 6 + 12);
  const band = (score / 40 * 9).toFixed(1);

  if (window.parent) {
    window.parent.postMessage({
      type: 'IELTS_TEST_COMPLETE',
      section: 'LISTENING',
      rawScore: score,
      maxScore: 40,
      bandScore: parseFloat(band),
      resultData: { filled: filledCount, testNumber: 2 }
    }, '*');
  }

  alert('Section submitted! Score: ' + score + '/40 (Est. Band ' + band + ')');
});