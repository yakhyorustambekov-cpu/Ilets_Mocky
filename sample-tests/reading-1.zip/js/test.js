document.getElementById('readingSubmitBtn').addEventListener('click', function() {
  const selects = document.querySelectorAll('select');
  let answered = 0;
  selects.forEach(s => { if (s.value) answered++; });

  const rawScore = 32;
  const band = 7.5;

  if (window.parent) {
    window.parent.postMessage({
      type: 'IELTS_TEST_COMPLETE',
      section: 'READING',
      rawScore: rawScore,
      maxScore: 40,
      bandScore: band,
      resultData: { testNumber: 1, answered: answered }
    }, '*');
  }

  alert('Reading Section completed! Recorded Band: ' + band);
});